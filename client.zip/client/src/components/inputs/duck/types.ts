export interface BaseInputProps {
  label: string;
  name: string;
  helperText?: string;
}