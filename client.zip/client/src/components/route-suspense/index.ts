export { default } from "./route-suspense.tsx";
