export { default } from "./resource.tsx";
