export interface ApiResponseErrors {
  errors: {
    [key: string]: string;
  };
}
