import * as yup from "yup";

export default yup;