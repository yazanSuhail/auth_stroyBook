export { default } from "./not-authorized.tsx";
