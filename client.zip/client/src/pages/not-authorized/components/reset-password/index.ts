export { default } from "./reset-password.tsx";
