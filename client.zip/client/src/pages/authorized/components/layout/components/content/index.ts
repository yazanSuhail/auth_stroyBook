export { default } from "./content.tsx";
