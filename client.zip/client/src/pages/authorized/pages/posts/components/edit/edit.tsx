import React from "react";

const Edit: React.FC = () => {
  return <div>edit</div>;
};

export default Edit;