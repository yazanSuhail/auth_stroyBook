import React from "react";

const Show: React.FC = () => {
  return <div>show</div>;
};

export default Show;