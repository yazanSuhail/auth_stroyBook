export { default } from "./show.tsx";
