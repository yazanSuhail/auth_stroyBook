import React from "react";

const Create: React.FC = () => {
  return <div>create</div>;
};

export default Create;