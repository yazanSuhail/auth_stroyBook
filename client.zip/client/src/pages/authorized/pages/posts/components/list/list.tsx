import React from "react";

const List: React.FC = () => {
  return <div>list 1</div>;
};

export default List;