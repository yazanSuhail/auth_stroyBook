export { default } from "./posts.tsx";
