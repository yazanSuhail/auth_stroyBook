export { default as Posts } from "./posts";
