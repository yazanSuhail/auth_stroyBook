export { default } from "./authorized.tsx";
